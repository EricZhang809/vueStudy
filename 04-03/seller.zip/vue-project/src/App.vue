<template>
	<div id="app">
		App组件
	</div>
</template>
<script>
	export default {
		name: 'app',
		created() {
			
		}
	}
</script>

<style>
	#app {
		background: #0f0;
	}
</style>