module.exports = {
	HTTP_PORT: 9090,
	HTTP_HOST: 'localhost'
}